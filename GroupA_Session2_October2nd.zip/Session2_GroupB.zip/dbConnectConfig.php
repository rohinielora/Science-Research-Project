<?php
$servername = "localhost";
$port = 3306;
$username = "rohiniex_meg";
$password = "eb;?~YInAA4a";
$dbname = "rohiniex_meg";
// $table = "mvaghi_newtable";
//
?>
