<?php
// this path should point to your configuration file:
include('dbConnectConfig.php');

$db =  new mysqli($servername, $username, $password,$dbname);
if (mysqli_connect_errno()) {
  printf("DB error: %s", mysqli_connect_error());
  exit();
}

$subjectId = stripslashes(htmlspecialchars($_POST['subjectId']));
$run = stripslashes(htmlspecialchars($_POST['run']));
$map = stripslashes(htmlspecialchars($_POST['map']));
$trial = stripslashes(htmlspecialchars($_POST['trial']));
$nodeNumImg1 = stripslashes(htmlspecialchars($_POST['nodeNumImg1']));
$imgFileName1 = stripslashes(htmlspecialchars($_POST['imgFileName1']));
$nodeNumImg2= stripslashes(htmlspecialchars($_POST['nodeNumImg2']));
$imgFileName2= stripslashes(htmlspecialchars($_POST['imgFileName2']));
$rt= stripslashes(htmlspecialchars($_POST['rt']));



$stmt = $db->prepare("INSERT INTO learnRandomPairsTable VALUE(?,?,?,?,?,?,?,?,?)");//I also insert the time
$stmt->bind_param("siiiisisd", $subjectId, $run,$map,$trial,$nodeNumImg1,$imgFileName1,$nodeNumImg2,$imgFileName2,$rt);//s=string, i=integer, d=double
$stmt->execute();
$err = $stmt->errno ;
$data[] = array(
  'ErrorNo' => $err,
);
$stmt->close();
$db->close();
echo json_encode($data);
?>
